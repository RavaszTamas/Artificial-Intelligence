# -*- coding: utf-8 -*-
"""
Created on Fri Jun  5 17:33:19 2020

@author: tamas
"""
from Controller import Controller

if __name__ == "__main__":
    controller = Controller()
    
    controller.start()